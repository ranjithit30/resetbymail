<?php
include("config.php");
if (!isset($_GET["code"])) {
    exit("cant find the page");
}
$code       = $_GET["code"];
$emailquery = mysqli_query($con, "SELECT email from resetpassword WHERE code='$code'");
if (mysqli_num_rows($emailquery) == 0) {
    exit("cant load page");
}
if (isset($_POST["password"])) {
    $pw    = $_POST["password"];
    $row   = mysqli_fetch_array($emailquery);
    $email = $row["email"];
    $query = mysqli_query($con, "UPDATE users SET password='$pw' where email='$email'");
    if ($query) {
        $query = mysqli_query($con, "DELETE FROM resetpassword WHERE code='$code'");
        echo '<script>alert("Password Updated Successfully")</script>';
    } else {
        exit("something went wrong");
    }
}
?>
<html>
<head>
    <title>Resetting Password</title>
    <link rel="stylesheet" type="text/css" href="style.scss">
</head>
<body>
<form method="POST">
<input type="password" class="input" name="password" placeholder="New Password" required="required">
<br>
<div class="container">
    <input type="submit" class="btn" value="UPDATE PASSWORD">
    </div>
</form>
</body>
</html>