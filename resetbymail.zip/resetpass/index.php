<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
 
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'config.php'; 

if(isset($_POST["email"])){

    $emailid=$_POST["email"];
    $code=uniqid(true);
    $query=mysqli_query($con,"INSERT INTO resetpassword(code,email) VALUES('$code','$emailid')");
    if(!$query){
        exit("Error");
    }
    $mail = new PHPMailer(true);

    try {
    //Server settings                   // Enable verbose debug output
    $mail->isSMTP();                                            // Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                    // Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
    $mail->Username   = '17it025@gmail.com';                     // SMTP username
    $mail->Password   = 'Lakshmi@13';                               // SMTP password
    $mail->SMTPSecure = 'ssl';         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
    $mail->Port       = 465;                                    // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above

    //Recipients
    $mail->setFrom('17it025@gmail.com', 'RANJITH MRK');
    $mail->addAddress($emailid);     // Add a recipient           // Name is optional
    $mail->addReplyTo('17it025@gmail.com', 'no reply');


    // Content
    $url="http://".$_SERVER["HTTP_HOST"].dirname($_SERVER["PHP_SELF"])."/reset.php?code=$code";
    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = 'your password reset link';
    $mail->Body    = "click<a href='$url'>this link</a>";
    $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

    $mail->send();
    echo '<script>alert("reset password link has been sent to your mailid")</script>'; 
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}

}

?>
<html>
<head>
<link rel="stylesheet" type="text/css" href="style.scss">

</head>
<body>
<form method="POST">
  <div>
    <input type="text" class="input" name="email" placeholder="Your registered email id" style="">
</div>
    <br>
    <div class="container">
    <input type="submit" class="btn" value="RESET PASSWORD →">
    </div>
</form>
</body>
</html>
